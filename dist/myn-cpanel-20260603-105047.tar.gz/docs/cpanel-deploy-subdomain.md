# Ship to a cPanel subdomain — staging / UAT guide

A focused walkthrough for deploying the Makueni Youth Network CMS to a
**subdomain** on the same cPanel account that hosts production — e.g.
`uat.makueniyouth.org`, `staging.makueniyouth.org`, `dev.makueniyouth.org`.

This is the companion to [`cpanel-deploy.md`](cpanel-deploy.md). Read that
one first — it explains the layout, the build script, permissions, SSL and
the update loop. This file only covers what's **different** when the target
is a subdomain instead of the apex domain.

End-to-end time: **20–30 minutes** the first time.

> **Throughout this guide** the subdomain is `uat.makueniyouth.org` and the
> cPanel document root for that subdomain is **`/uat.makueniyouth.org`**
> (i.e. `/home/<user>/uat.makueniyouth.org/`). That is the literal path
> cPanel created when the subdomain was added. Substitute your own values
> if you're standing up `staging.`, `dev.`, etc.

---

## 1 · Create the subdomain in cPanel

cPanel → **Domains** (older accounts: **Subdomains**) → **Create A New Domain**.

| Field            | Value                                                       |
|------------------|-------------------------------------------------------------|
| Domain           | `uat.makueniyouth.org`                                      |
| Share doc root   | **untick** — do NOT share with `makueniyouth.org`           |
| Document Root    | `/uat.makueniyouth.org` *(cPanel's default for this subdomain)* |

After Create, cPanel writes the folder `/home/<user>/uat.makueniyouth.org/`
and adds a DNS A-record automatically **if** your nameservers point at this
cPanel host. If DNS lives elsewhere (Cloudflare, the registrar), add an
`A` record yourself: `uat` → your server's IPv4. Propagation: 1 – 30 min.

Quick check from your laptop:

```bash
dig +short uat.makueniyouth.org      # should return the same IP as makueniyouth.org
```

---

## 2 · The server layout

You'll end up with a parallel tree alongside production:

```
/home/<user>/
├── backups/                       # nightly DB + uploads dumps
├── myn/                           # LIVE project root (not browser-reachable)
├── myn-uat/                       # UAT project root (not browser-reachable)  ← new
├── public_html/                   # LIVE DocumentRoot — makueniyouth.org
└── uat.makueniyouth.org/          # UAT DocumentRoot — uat.makueniyouth.org   ← new
```

The two halves never touch. Different DB, different `.env`, different
admin password, different uploads folder. The only thing they share is the
cPanel account itself.

---

## 3 · Build & upload the artifact

Same as production — on your laptop:

```bash
scripts/build-deploy.sh
```

Upload `dist/myn-cpanel-*.tar.gz` into `~/` via File Manager. Extract it
to `~/myn-uat/` (rename if cPanel extracts it to a different folder).

With SSH:

```bash
mkdir -p ~/myn-uat
tar -xzf ~/myn-cpanel-*.tar.gz -C ~/myn-uat
```

### 3.1 · Move `public/` contents into the subdomain doc root

Move every file under `~/myn-uat/public/` into `~/uat.makueniyouth.org/`,
then delete the now-empty `~/myn-uat/public/`.

| With SSH | Without SSH |
|---|---|
| `rsync -av ~/myn-uat/public/ ~/uat.makueniyouth.org/ && rm -rf ~/myn-uat/public` | File Manager: open `~/myn-uat/public/` on the right, `~/uat.makueniyouth.org/` on the left, select-all, drag across, then delete the empty `public/` folder. |

### 3.2 · Point `index.php` at the UAT project root

Open `~/uat.makueniyouth.org/index.php` in the cPanel editor and change
**only the `$rootDir` line**:

```php
// Before (assumes public/ is a child of the project root):
$rootDir = dirname(__DIR__);

// After (Layout A — index.php lives in ~/uat.makueniyouth.org/, project in ~/myn-uat/):
$rootDir = dirname(__DIR__) . '/myn-uat';
```

Delete `~/uat.makueniyouth.org/server.php` — it's only useful as a
PHP-built-in-server router on your laptop.

### 3.3 · Lock down the project root

Create `~/myn-uat/.htaccess` (Show Hidden Files must be on in File Manager
Settings):

```apache
Require all denied
```

### 3.4 · Permissions

| Path                           | Mode |
|--------------------------------|------|
| Everything else                | 755 dirs / 644 files |
| `~/uat.makueniyouth.org/uploads/` | **775** |
| `~/myn-uat/storage/logs/`         | **775** |

SSH equivalent:

```bash
find ~/myn-uat -type d -exec chmod 755 {} \;
find ~/myn-uat -type f -exec chmod 644 {} \;
chmod -R 775 ~/myn-uat/storage/logs ~/uat.makueniyouth.org/uploads
```

---

## 4 · Create a **separate** database

This is the rule, no exceptions: **UAT must never point at the production
database.** One typo in an admin form on staging would otherwise mutate
real data.

cPanel → **MySQL Databases**:

1. Create DB `myn_uat` → cPanel prefixes it (e.g. `acme_myn_uat`).
2. Add user `myn_uat_user`, generate a strong password.
3. Grant the user **ALL PRIVILEGES** on `acme_myn_uat`.

Then phpMyAdmin → select `acme_myn_uat` → **Import** → upload
`database/schema.sql`, then `database/seed.sql`. Sanity-check:

```sql
SHOW TABLES;
SELECT COUNT(*) FROM users;     -- 1
SELECT COUNT(*) FROM programs;  -- 5
```

---

## 5 · `.env` for UAT

File Manager → `~/myn-uat/` → **+ File** → `.env` → edit:

```dotenv
APP_ENV=local                                  # surfaces stack traces in the browser while testing
APP_URL=https://uat.makueniyouth.org
APP_KEY=                                       # generate a FRESH one, different from prod

DB_HOST=localhost
DB_NAME=acme_myn_uat                           # the prefixed name from step 4
DB_USER=acme_myn_uat_user
DB_PASS=the-password-you-generated

MAIL_HOST=mail.makueniyouth.org
MAIL_PORT=587
MAIL_USER=uat@makueniyouth.org                 # dedicated UAT mailbox preferred
MAIL_PASS=the-mailbox-password
MAIL_FROM=uat@makueniyouth.org

PAYSTACK_ENV=test
PAYSTACK_PUBLIC_KEY=pk_test_...                # TEST keys — never live
PAYSTACK_SECRET_KEY=sk_test_...
PAYSTACK_CALLBACK_URL=https://uat.makueniyouth.org/donate/callback
PAYSTACK_CURRENCY=KES
```

### 5.1 · Fresh `APP_KEY`

```bash
php -r "echo bin2hex(random_bytes(32));"
```

Use a **different** value to the one in production. Sharing the key means
a token signed on UAT validates on prod (and vice versa) — staging stops
being staging.

### 5.2 · Why `APP_ENV=local` on UAT

Production runs `APP_ENV=production` so visitors see friendly 500 pages.
UAT exists for you to break things and inspect them, so `local` is the
right default — stack traces render in-browser and there's no friction
between "I see the error" and "I know which file to open". Flip it to
`production` for the last round of pre-release testing if you want a true
prod parity check.

---

## 6 · PHP version

cPanel → **MultiPHP Manager** → tick `uat.makueniyouth.org` → set to
**ea-php82** (or whichever minor version production runs). Keep them in
sync — UAT is worthless as a test bed if it's running a different PHP than
prod does.

---

## 7 · Turn on HTTPS

cPanel → **SSL/TLS Status** → tick `uat.makueniyouth.org` → **Run AutoSSL**.
Wait 1–2 min, refresh. The bundled `public/.htaccess` already force-redirects
HTTP → HTTPS, so once the cert is live no edits are needed.

```bash
curl -I http://uat.makueniyouth.org/      # 301 → https
curl -I https://uat.makueniyouth.org/     # 200 (or 401 once §8 is on)
```

---

## 8 · Keep UAT private — two controls, both worth doing

A staging URL that Google indexes is a SEO + reputational liability: half-
finished copy, test donations, broken redirects — all crawlable. Add both
of these on day one.

### 8.1 · `robots.txt` — keep crawlers out

Overwrite `~/uat.makueniyouth.org/robots.txt`:

```
User-agent: *
Disallow: /
```

This is advisory only. Honest crawlers obey; the rest don't. That's why
you also do 8.2.

### 8.2 · Directory Privacy — keep humans out

cPanel → **Directory Privacy** → navigate into `uat.makueniyouth.org/` →
tick **"Password protect this directory"** → set the protected resource
name to something like `MYN UAT` → **Save** → then **Create User** with a
strong password.

Now every request to `https://uat.makueniyouth.org/...` is gated by an
HTTP Basic Auth prompt. You and the team type it once per browser session.
Random visitors and search bots hit `401 Unauthorized` and bounce.

Verify:

```bash
curl -I https://uat.makueniyouth.org/                                       # 401
curl -I -u uatuser:uatpass https://uat.makueniyouth.org/                    # 200
```

> **Heads up — Paystack callbacks & webhooks.** Basic Auth on the whole
> subdomain will also block Paystack's webhook POSTs to
> `https://uat.makueniyouth.org/donate/webhook`. If you actually need to
> exercise webhooks on UAT (most of the time you don't — test mode +
> client-side verify is enough), exclude the webhook path. Add this to
> `~/uat.makueniyouth.org/.htaccess` ABOVE the front-controller rewrite:
>
> ```apache
> <If "%{REQUEST_URI} =~ m#^/donate/webhook#">
>     Satisfy Any
>     Allow from all
> </If>
> ```

---

## 9 · First admin login & password rotation

`https://uat.makueniyouth.org/admin/login`:

| | |
|---|---|
| Email    | `admin@makueniyouth.org` |
| Password | `ChangeMe2026!`          |

Rotate immediately to a password **different from production**'s. The
single biggest source of staging-to-prod accidents is reusing creds and
then typing prod commands at a UAT tab (or vice versa).

---

## 10 · Smoke-test

```bash
HOST=https://uat.makueniyouth.org
AUTH="-u uatuser:uatpass"      # the Directory Privacy creds from §8.2

curl $AUTH -s -o /dev/null -w '%{http_code}\n' $HOST/                       # 200
curl $AUTH -s -o /dev/null -w '%{http_code}\n' $HOST/programs               # 200
curl $AUTH -s -o /dev/null -w '%{http_code}\n' $HOST/impact                 # 200
curl $AUTH -s -o /dev/null -w '%{http_code}\n' $HOST/sitemap.xml            # 200
curl $AUTH -s -o /dev/null -w '%{http_code}\n' $HOST/admin                  # 302 → /admin/login
curl $AUTH -s -o /dev/null -w '%{http_code}\n' $HOST/no-such-page           # 404

curl -I $HOST/.env                                                          # 401 (or 403) — NEVER 200
curl -I $HOST/storage/logs/app.log                                          # 401 / 403 / 404 — NEVER 200
```

Open the site in a browser, log in, click through Programs → Impact →
Donate → submit a test Paystack transaction with card `4084 0840 8408 4081`
(Paystack's universal test card) — it should redirect through the test
gateway and land on the success page.

---

## 11 · The update loop (promote prod → UAT, or test a feature)

On your laptop:

```bash
git pull origin main           # or git checkout <feature-branch>
scripts/build-deploy.sh
```

In cPanel:

1. **File Manager** → upload the new tarball.
2. Rename `~/myn-uat/` → `~/myn-uat-old-YYYYMMDD/` (rollback insurance).
3. Extract the new tarball to `~/myn-uat/`.
4. Move `~/myn-uat/public/*` into `~/uat.makueniyouth.org/` (rsync if SSH).
5. Copy `.env` from the old folder back into `~/myn-uat/.env`.
6. If the release ships SQL migrations, import them via phpMyAdmin into
   `acme_myn_uat` **only** — don't accidentally point phpMyAdmin at the
   prod DB.

Rollback is: rename `~/myn-uat-old-*` back to `~/myn-uat/`.

---

## 12 · Refreshing UAT data from production (optional)

Once UAT has run a while, the staging DB drifts from production. To pull
a snapshot:

```bash
# On the server, via SSH
mysqldump --single-transaction -u acme_myn_user -p'PROD_PASS' acme_myn_db \
  | mysql -u acme_myn_uat_user -p'UAT_PASS' acme_myn_uat
```

Then in phpMyAdmin against `acme_myn_uat`:

```sql
-- Lock down the admin account so prod creds don't carry over
UPDATE users SET password = '$2y$12$REPLACE_ME_WITH_A_BCRYPT_HASH'
WHERE email = 'admin@makueniyouth.org';

-- Optional: wipe donor PII if real donations exist
DELETE FROM donations WHERE created_at < NOW() - INTERVAL 30 DAY;
```

Mirror the `public_html/uploads/` folder too if the admin work depends on
specific media being present:

```bash
rsync -av ~/public_html/uploads/ ~/uat.makueniyouth.org/uploads/
```

---

## 13 · Security checklist for UAT go-live

- [ ] Subdomain `uat.makueniyouth.org` resolves (`dig +short uat...` returns the right IP)
- [ ] AutoSSL is green for the subdomain; HTTP → HTTPS redirect works
- [ ] Directory Privacy is enabled — anonymous `curl` returns `401`
- [ ] `robots.txt` disallows everything
- [ ] **Separate** database (`acme_myn_uat`) — no shared connection to prod DB
- [ ] **Fresh** `APP_KEY` (not the same as production's)
- [ ] **Test** Paystack keys (`pk_test_...`, `sk_test_...`)
- [ ] **Different** admin password to production's
- [ ] `~/myn-uat/.htaccess` contains `Require all denied`
- [ ] `https://uat.makueniyouth.org/.env` returns 401 / 403, never the file
- [ ] `~/uat.makueniyouth.org/uploads/` and `~/myn-uat/storage/logs/` are 775

---

## 14 · The three failure modes that cause real damage

In descending order of how much pain they cause:

1. **Live Paystack keys on UAT.** Real donor cards get charged for test
   submissions. Always use `pk_test_...` / `sk_test_...` on staging.
2. **Same DB credentials as production.** A QA tester clicks "Delete
   programme" on what they think is staging and removes the entry from
   prod. Always provision a separate DB + user.
3. **Reused `APP_KEY` or admin password.** Tokens cross-validate between
   environments and a leaked staging credential opens the prod door.
   Generate both fresh.

---

## Appendix · Quick-reference layout

After a successful subdomain deploy your account looks like:

```
/home/<cpanel-user>/
├── backups/                              # nightly dumps for prod (and optionally UAT)
├── myn/                                  # prod project root
│   ├── .env
│   ├── .htaccess                         # "Require all denied"
│   ├── app/ config/ database/ routes/ storage/ templates/ vendor/
│   └── ...
├── myn-uat/                              # UAT project root  ← this guide
│   ├── .env                              # test keys, separate APP_KEY
│   ├── .htaccess                         # "Require all denied"
│   ├── app/ config/ database/ routes/ storage/ templates/ vendor/
│   └── ...
├── public_html/                          # prod DocumentRoot — makueniyouth.org
│   ├── .htaccess index.php assets/ uploads/ robots.txt favicon.png ...
└── uat.makueniyouth.org/                 # UAT DocumentRoot — Directory-Privacy-gated
    ├── .htaccess                         # (optionally) carves out /donate/webhook
    ├── .htpasswd                         # auto-created by Directory Privacy
    ├── index.php                         # $rootDir = dirname(__DIR__) . '/myn-uat'
    ├── assets/
    ├── uploads/
    ├── robots.txt                        # Disallow: /
    └── favicon.png ...
```

Two independent stacks, one cPanel login, zero shared blast radius.
